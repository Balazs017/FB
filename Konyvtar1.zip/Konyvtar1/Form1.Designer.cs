﻿namespace Konyvtar1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            kkUj = new Button();
            kkTorol = new Button();
            kkModosit = new Button();
            kkFelvesz = new Button();
            kkKiad = new TextBox();
            label4 = new Label();
            kkCim = new TextBox();
            label3 = new Label();
            kkSzerzo = new TextBox();
            label2 = new Label();
            KKAzon = new TextBox();
            label1 = new Label();
            kkListBox = new ListBox();
            tabPage2 = new TabPage();
            OlvUj = new Button();
            OlvTorol = new Button();
            OlvModosit = new Button();
            OlvFelvesz = new Button();
            OlvKor = new TextBox();
            label77 = new Label();
            OlvCim = new TextBox();
            label6 = new Label();
            OlvNev = new TextBox();
            label45 = new Label();
            OlvAzon = new TextBox();
            label8 = new Label();
            OlvListBox = new ListBox();
            tabPage3 = new TabPage();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Location = new Point(15, 15);
            tabControl1.Margin = new Padding(4);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(970, 541);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.Silver;
            tabPage1.Controls.Add(kkUj);
            tabPage1.Controls.Add(kkTorol);
            tabPage1.Controls.Add(kkModosit);
            tabPage1.Controls.Add(kkFelvesz);
            tabPage1.Controls.Add(kkKiad);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(kkCim);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(kkSzerzo);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(KKAzon);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(kkListBox);
            tabPage1.Location = new Point(4, 34);
            tabPage1.Margin = new Padding(4);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(4);
            tabPage1.Size = new Size(962, 503);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Könyvek";
            // 
            // kkUj
            // 
            kkUj.Location = new Point(812, 451);
            kkUj.Name = "kkUj";
            kkUj.Size = new Size(121, 34);
            kkUj.TabIndex = 12;
            kkUj.Text = "Új könyv";
            kkUj.UseVisualStyleBackColor = true;
            kkUj.Click += kkUj_Click;
            // 
            // kkTorol
            // 
            kkTorol.Location = new Point(812, 238);
            kkTorol.Name = "kkTorol";
            kkTorol.Size = new Size(112, 34);
            kkTorol.TabIndex = 11;
            kkTorol.Text = "Töröl";
            kkTorol.UseVisualStyleBackColor = true;
            kkTorol.Click += kkTorol_Click;
            // 
            // kkModosit
            // 
            kkModosit.Location = new Point(812, 135);
            kkModosit.Name = "kkModosit";
            kkModosit.Size = new Size(112, 34);
            kkModosit.TabIndex = 10;
            kkModosit.Text = "Módosít";
            kkModosit.UseVisualStyleBackColor = true;
            kkModosit.Click += kkModosit_Click;
            // 
            // kkFelvesz
            // 
            kkFelvesz.Location = new Point(812, 340);
            kkFelvesz.Margin = new Padding(4);
            kkFelvesz.Name = "kkFelvesz";
            kkFelvesz.Size = new Size(121, 42);
            kkFelvesz.TabIndex = 9;
            kkFelvesz.Text = "Felvesz";
            kkFelvesz.UseVisualStyleBackColor = true;
            kkFelvesz.Click += kkFelvesz_Click;
            // 
            // kkKiad
            // 
            kkKiad.Location = new Point(692, 454);
            kkKiad.Margin = new Padding(4);
            kkKiad.Name = "kkKiad";
            kkKiad.Size = new Size(96, 31);
            kkKiad.TabIndex = 8;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(692, 425);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(95, 25);
            label4.TabIndex = 7;
            label4.Text = "Kiadás éve";
            // 
            // kkCim
            // 
            kkCim.Location = new Point(396, 454);
            kkCim.Margin = new Padding(4);
            kkCim.Name = "kkCim";
            kkCim.Size = new Size(288, 31);
            kkCim.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(396, 425);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(43, 25);
            label3.TabIndex = 5;
            label3.Text = "Cím";
            // 
            // kkSzerzo
            // 
            kkSzerzo.Location = new Point(116, 454);
            kkSzerzo.Margin = new Padding(4);
            kkSzerzo.Name = "kkSzerzo";
            kkSzerzo.Size = new Size(272, 31);
            kkSzerzo.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(116, 425);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(63, 25);
            label2.TabIndex = 3;
            label2.Text = "Szerző";
            // 
            // KKAzon
            // 
            KKAzon.Location = new Point(11, 454);
            KKAzon.Margin = new Padding(4);
            KKAzon.Name = "KKAzon";
            KKAzon.Size = new Size(96, 31);
            KKAzon.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(11, 425);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(93, 25);
            label1.TabIndex = 1;
            label1.Text = "Azonosító";
            // 
            // kkListBox
            // 
            kkListBox.FormattingEnabled = true;
            kkListBox.ItemHeight = 25;
            kkListBox.Location = new Point(8, 16);
            kkListBox.Margin = new Padding(4);
            kkListBox.Name = "kkListBox";
            kkListBox.Size = new Size(779, 404);
            kkListBox.TabIndex = 0;
            kkListBox.SelectedIndexChanged += kkListBox_SelectedIndexChanged;
            // 
            // tabPage2
            // 
            tabPage2.BackColor = Color.Gainsboro;
            tabPage2.Controls.Add(OlvUj);
            tabPage2.Controls.Add(OlvTorol);
            tabPage2.Controls.Add(OlvModosit);
            tabPage2.Controls.Add(OlvFelvesz);
            tabPage2.Controls.Add(OlvKor);
            tabPage2.Controls.Add(label77);
            tabPage2.Controls.Add(OlvCim);
            tabPage2.Controls.Add(label6);
            tabPage2.Controls.Add(OlvNev);
            tabPage2.Controls.Add(label45);
            tabPage2.Controls.Add(OlvAzon);
            tabPage2.Controls.Add(label8);
            tabPage2.Controls.Add(OlvListBox);
            tabPage2.Location = new Point(4, 34);
            tabPage2.Margin = new Padding(4);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(4);
            tabPage2.Size = new Size(962, 503);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Olvasók";
            // 
            // OlvUj
            // 
            OlvUj.Location = new Point(823, 452);
            OlvUj.Name = "OlvUj";
            OlvUj.Size = new Size(121, 34);
            OlvUj.TabIndex = 25;
            OlvUj.Text = "Új olvasó";
            OlvUj.UseVisualStyleBackColor = true;
            OlvUj.Click += OlvUj_Click;
            // 
            // OlvTorol
            // 
            OlvTorol.Location = new Point(823, 239);
            OlvTorol.Name = "OlvTorol";
            OlvTorol.Size = new Size(112, 34);
            OlvTorol.TabIndex = 24;
            OlvTorol.Text = "Töröl";
            OlvTorol.UseVisualStyleBackColor = true;
            OlvTorol.Click += OlvTorol_Click;
            // 
            // OlvModosit
            // 
            OlvModosit.Location = new Point(823, 136);
            OlvModosit.Name = "OlvModosit";
            OlvModosit.Size = new Size(112, 34);
            OlvModosit.TabIndex = 23;
            OlvModosit.Text = "Módosít";
            OlvModosit.UseVisualStyleBackColor = true;
            OlvModosit.Click += OlvModosit_Click;
            // 
            // OlvFelvesz
            // 
            OlvFelvesz.Location = new Point(823, 341);
            OlvFelvesz.Margin = new Padding(4);
            OlvFelvesz.Name = "OlvFelvesz";
            OlvFelvesz.Size = new Size(121, 42);
            OlvFelvesz.TabIndex = 22;
            OlvFelvesz.Text = "Felvesz";
            OlvFelvesz.UseVisualStyleBackColor = true;
            OlvFelvesz.Click += OlvFelvesz_Click;
            // 
            // OlvKor
            // 
            OlvKor.Location = new Point(703, 455);
            OlvKor.Margin = new Padding(4);
            OlvKor.Name = "OlvKor";
            OlvKor.Size = new Size(96, 31);
            OlvKor.TabIndex = 21;
            // 
            // label77
            // 
            label77.AutoSize = true;
            label77.Location = new Point(703, 426);
            label77.Margin = new Padding(4, 0, 4, 0);
            label77.Name = "label77";
            label77.Size = new Size(39, 25);
            label77.TabIndex = 20;
            label77.Text = "Kor";
            // 
            // OlvCim
            // 
            OlvCim.Location = new Point(407, 455);
            OlvCim.Margin = new Padding(4);
            OlvCim.Name = "OlvCim";
            OlvCim.Size = new Size(288, 31);
            OlvCim.TabIndex = 19;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(407, 426);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(109, 25);
            label6.TabIndex = 18;
            label6.Text = "Olvasó címe";
            // 
            // OlvNev
            // 
            OlvNev.Location = new Point(127, 455);
            OlvNev.Margin = new Padding(4);
            OlvNev.Name = "OlvNev";
            OlvNev.Size = new Size(272, 31);
            OlvNev.TabIndex = 17;
            // 
            // label45
            // 
            label45.AutoSize = true;
            label45.Location = new Point(127, 426);
            label45.Margin = new Padding(4, 0, 4, 0);
            label45.Name = "label45";
            label45.Size = new Size(109, 25);
            label45.TabIndex = 16;
            label45.Text = "Olvasó neve";
            // 
            // OlvAzon
            // 
            OlvAzon.Location = new Point(22, 455);
            OlvAzon.Margin = new Padding(4);
            OlvAzon.Name = "OlvAzon";
            OlvAzon.Size = new Size(96, 31);
            OlvAzon.TabIndex = 15;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(22, 426);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(93, 25);
            label8.TabIndex = 14;
            label8.Text = "Azonosító";
            // 
            // OlvListBox
            // 
            OlvListBox.FormattingEnabled = true;
            OlvListBox.ItemHeight = 25;
            OlvListBox.Location = new Point(19, 17);
            OlvListBox.Margin = new Padding(4);
            OlvListBox.Name = "OlvListBox";
            OlvListBox.Size = new Size(779, 404);
            OlvListBox.TabIndex = 13;
            OlvListBox.SelectedIndexChanged += OlvListBox_SelectedIndexChanged;
            // 
            // tabPage3
            // 
            tabPage3.BackColor = Color.SeaShell;
            tabPage3.Location = new Point(4, 34);
            tabPage3.Margin = new Padding(4);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new Size(962, 503);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Kölcsönzések";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1004, 571);
            Controls.Add(tabControl1);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "Könyvtár";
            FormClosing += Form1_FormClosing;
            Load += Form1_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private ListBox kkListBox;
        private TextBox KKAzon;
        private Label label1;
        private Button kkFelvesz;
        private TextBox kkKiad;
        private Label label4;
        private TextBox kkCim;
        private Label label3;
        private TextBox kkSzerzo;
        private Label label2;
        private Button kkTorol;
        private Button kkModosit;
        private Button kkUj;
        private Button OlvUj;
        private Button OlvTorol;
        private Button OlvModosit;
        private Button OlvFelvesz;
        private TextBox OlvKor;
        private Label label77;
        private TextBox OlvCim;
        private Label label6;
        private TextBox OlvNev;
        private Label label45;
        private TextBox OlvAzon;
        private Label label8;
        private ListBox OlvListBox;
    }
}
