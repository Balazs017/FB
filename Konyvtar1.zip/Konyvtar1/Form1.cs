namespace Konyvtar1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader(@"..\..\..\konyvek.txt");
            string sor = sr.ReadLine();
            while (sor != null)
            {
                if (sor.Trim() != "")
                {
                    string szebbSor = sor.Replace(";", "  :  ");
                    kkListBox.Items.Add(szebbSor);
                }
                sor = sr.ReadLine();
            }
            sr.Close();

            StreamReader sro = new StreamReader(@"..\..\..\olvasok.txt");
            string sorOlv = sro.ReadLine();
            while (sorOlv != null)
            {
                if (sorOlv.Trim() != "")
                {
                    string szebbSor = sorOlv.Replace(";", "  :  ");
                    OlvListBox.Items.Add(szebbSor);
                }
                sorOlv = sro.ReadLine();
            }
            sro.Close();
        }

        private void kkFelvesz_Click(object sender, EventArgs e)
        {
            try
            {
                int azon = int.Parse(KKAzon.Text);
                bool van = false; // van-e m�r ilyen azonos�t�
                for (int i = 0; i < kkListBox.Items.Count; i++)
                {
                    int ezazazon = int.Parse(kkListBox.Items[i].ToString().Substring(0, 4));
                    if (azon == ezazazon)
                    {
                        van = true;
                    }
                }
                if (!van && azon >= 1000 && azon <= 9999)
                {
                    // j� az azonos�t�
                    string sor = $"{azon}  :  {kkSzerzo.Text}  :  {kkCim.Text}  :  {kkKiad.Text}";
                    kkListBox.Items.Add(sor);
                    KKAzon.Text = "";
                    kkSzerzo.Text = "";
                    kkCim.Text = "";
                    kkKiad.Text = "";
                }
                else
                {
                    MessageBox.Show("Hib�s azonos�t�!");
                    KKAzon.Focus();
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Hib�s azonos�t�!");
                KKAzon.Focus();
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            StreamWriter sw = new StreamWriter(@"..\..\..\konyvek.txt");
            for (int i = 0; i < kkListBox.Items.Count; i++)
            {
                string sor = kkListBox.Items[i].ToString().Replace("  :  ", ";");
                sw.WriteLine(sor);
            }
            sw.Close();

            StreamWriter swOlv = new StreamWriter(@"..\..\..\olvasok.txt");
            for (int i = 0; i < OlvListBox.Items.Count; i++)
            {
                string sor = OlvListBox.Items[i].ToString().Replace("  :  ", ";");
                swOlv.WriteLine(sor);
            }
            swOlv.Close();
        }

        private void kkListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (kkListBox.SelectedIndex != -1)
            {
                string[] felDarab = kkListBox.Items[kkListBox.SelectedIndex].ToString().Split("  :  ");
                KKAzon.Text = felDarab[0];
                kkSzerzo.Text = felDarab[1];
                kkCim.Text = felDarab[2];
                kkKiad.Text = felDarab[3];
            }
        }

        private void kkModosit_Click(object sender, EventArgs e)
        {
            if (kkListBox.SelectedIndex != -1)
                try
                {
                    int azon = int.Parse(KKAzon.Text);
                    bool van = false; // van-e m�sik!
                    for (int i = 0; i < kkListBox.Items.Count; i++)
                    {
                        int ezazazon = int.Parse(kkListBox.Items[i].ToString().Substring(0, 4));
                        if (azon == ezazazon && kkListBox.SelectedIndex != i)
                        {
                            van = true;
                        }
                    }
                    if (!van && azon >= 1000 && azon <= 9999)
                    {
                        // j� az azonos�t�
                        string sor = $"{azon}  :  {kkSzerzo.Text}  :  {kkCim.Text}  :  {kkKiad.Text}";
                        kkListBox.Items[kkListBox.SelectedIndex] = sor;
                    }
                    else
                    {
                        MessageBox.Show("Hib�s azonos�t�!");
                        KKAzon.Focus();
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show("Hib�s azonos�t�!");
                    KKAzon.Focus();
                }
        }

        private void kkTorol_Click(object sender, EventArgs e)
        {
            if (kkListBox.SelectedIndex >= 0)
            {
                DialogResult dr = MessageBox.Show("Val�ban t�rl�d?", "K�nyv t�rl�se", MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes)
                {
                    kkListBox.Items.RemoveAt(kkListBox.SelectedIndex);
                    KKAzon.Text = "";
                    kkSzerzo.Text = "";
                    kkCim.Text = "";
                    kkKiad.Text = "";
                }
            }
        }

        private void kkUj_Click(object sender, EventArgs e)
        {
            KKAzon.Text = "";
            kkSzerzo.Text = "";
            kkCim.Text = "";
            kkKiad.Text = "";
        }

        private void OlvUj_Click(object sender, EventArgs e)
        {
            OlvAzon.Text = "";
            OlvNev.Text = "";
            OlvCim.Text = "";
            OlvKor.Text = "";
        }

        private void OlvFelvesz_Click(object sender, EventArgs e)
        {
            try
            {
                int azon = int.Parse(OlvAzon.Text);
                bool van = false; // van-e m�r ilyen azonos�t�
                for (int i = 0; i < OlvListBox.Items.Count; i++)
                {
                    int ezazazon = int.Parse(OlvListBox.Items[i].ToString().Substring(0, 4));
                    if (azon == ezazazon)
                    {
                        van = true;
                    }
                }
                if (!van && azon >= 1000 && azon <= 9999)
                {
                    // j� az azonos�t�
                    string sor = $"{azon}  :  {OlvNev.Text}  :  {OlvCim.Text}  :  {OlvKor.Text}";
                    OlvListBox.Items.Add(sor);
                    OlvAzon.Text = "";
                    OlvNev.Text = "";
                    OlvCim.Text = "";
                    OlvKor.Text = "";
                }
                else
                {
                    MessageBox.Show("Hib�s azonos�t�!");
                    OlvAzon.Focus();
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Hib�s azonos�t�!");
                OlvAzon.Focus();
            }

        }

        private void OlvTorol_Click(object sender, EventArgs e)
        {
            if (OlvListBox.SelectedIndex >= 0)
            {
                DialogResult dr = MessageBox.Show("Val�ban t�rl�d?", "K�nyv t�rl�se", MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes)
                {
                    OlvListBox.Items.RemoveAt(OlvListBox.SelectedIndex);
                    OlvAzon.Text = "";
                    OlvNev.Text = "";
                    OlvCim.Text = "";
                    OlvKor.Text = "";
                }
            }
        }

        private void OlvModosit_Click(object sender, EventArgs e)
        {
            if (OlvListBox.SelectedIndex != -1)
                try
                {
                    int azon = int.Parse(OlvAzon.Text);
                    bool van = false; // van-e m�sik!
                    for (int i = 0; i < OlvListBox.Items.Count; i++)
                    {
                        int ezazazon = int.Parse(OlvListBox.Items[i].ToString().Substring(0, 4));
                        if (azon == ezazazon && OlvListBox.SelectedIndex != i)
                        {
                            van = true;
                        }
                    }
                    if (!van && azon >= 1000 && azon <= 9999)
                    {
                        // j� az azonos�t�
                        string sor = $"{azon}  :  {OlvNev.Text}  :  {OlvCim.Text}  :  {OlvKor.Text}";
                        OlvListBox.Items[OlvListBox.SelectedIndex] = sor;
                    }
                    else
                    {
                        MessageBox.Show("Hib�s azonos�t�!");
                        OlvAzon.Focus();
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show("Hib�s azonos�t�!");
                    OlvAzon.Focus();
                }
        }

        private void OlvListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (OlvListBox.SelectedIndex != -1)
            {
                string[] felDarab = OlvListBox.Items[OlvListBox.SelectedIndex].ToString().Split("  :  ");
                OlvAzon.Text = felDarab[0];
                OlvNev.Text = felDarab[1];
                OlvCim.Text = felDarab[2];
                OlvKor.Text = felDarab[3];
            }
        }
    }
}
